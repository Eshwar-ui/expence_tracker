# Python Version Compatibility Note

## Issue
TensorFlow does not currently support Python 3.14. TensorFlow typically supports Python versions up to 3.12.

## Solution

You have two options:

### Option 1: Use Python 3.11 or 3.12 (Recommended)

1. **Install Python 3.11 or 3.12** from [python.org](https://www.python.org/downloads/)
2. **Create a virtual environment** with the compatible version:
   ```bash
   py -3.11 -m venv venv
   # or
   py -3.12 -m venv venv
   ```
3. **Activate the virtual environment**:
   ```bash
   venv\Scripts\activate
   ```
4. **Install requirements**:
   ```bash
   pip install -r requirements.txt
   ```

### Option 2: Use Python 3.11/3.12 via py launcher

If you have multiple Python versions installed, you can use the `py` launcher:

```bash
# Create venv with Python 3.11
py -3.11 -m venv venv

# Activate
venv\Scripts\activate

# Install requirements
pip install -r requirements.txt
```

### Option 3: Use Docker (Alternative)

You can use a Docker container with Python 3.11/3.12:

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
```

## Checking Your Python Version

```bash
python --version
```

## Recommended Python Versions for TensorFlow

- **Python 3.11** - Fully supported
- **Python 3.12** - Fully supported  
- **Python 3.14** - Not yet supported

## TensorFlow Compatibility

- TensorFlow 2.15+ supports Python 3.9-3.12
- For Python 3.14, you'll need to wait for TensorFlow to add support

## Quick Fix

If you have Python 3.11 or 3.12 installed, use:

```bash
# Windows
py -3.11 -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

